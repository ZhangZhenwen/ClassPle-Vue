<template>

</template>

<script>
export default {
  name: "Interact"
}
</script>

<style scoped>

</style>
