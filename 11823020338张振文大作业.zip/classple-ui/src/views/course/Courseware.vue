<template>

</template>

<script>
export default {
  name: "Courseware"
}
</script>

<style scoped>

</style>
