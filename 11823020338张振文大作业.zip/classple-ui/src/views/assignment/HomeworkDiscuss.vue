<template>

</template>

<script>
export default {
  name: "HomeworkDiscuss"
}
</script>

<style scoped>

</style>
