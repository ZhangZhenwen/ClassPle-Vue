<template>

</template>

<script>
export default {
  name: "UserConfig"
}
</script>

<style scoped>

</style>
