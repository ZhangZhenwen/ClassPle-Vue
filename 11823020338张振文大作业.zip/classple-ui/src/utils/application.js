/**
 *
 * @author zhenwen
 * @date   2020/12/1
 */


export function isCourseTch(code) {
    return code === 'tch' || code === 'admin'
}

export function isCourseStu(code) {
    return code === 'stu'
}
